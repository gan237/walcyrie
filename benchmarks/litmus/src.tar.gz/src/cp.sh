cp $1 .
