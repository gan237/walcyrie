TMP=/tmp/dir.$$
mkdir -p $TMP
mcycles @DETOUR > $TMP/cy.txt
cat $TMP/cy.txt | grep PosRW |\
while read name cy
do
C=$(echo $cy | sed -e 's|PosRW|Fri|g')
#echo $name $C
N=$(grep -e ": $C$" $TMP/cy.txt | awk -F: '{print $1}')
case "$N" in
"")
;;
*)
echo $name $N
;;
esac
done
/bin/rm -rf $TMP