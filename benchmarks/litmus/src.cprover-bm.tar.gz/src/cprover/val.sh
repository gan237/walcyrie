#!/bin/bash

for f in src/*.c ; do
  bn=`basename $f .c`
  echo -n "$bn: " 1>&2
  echo -n "$bn: " 1>&2
  for m in sc tso pso rmo alpha ppc ; do
    mm=$m
    if [ x$m = xppc ] ; then
      mm=power
    fi
    echo -n "$bn:$mm:"
    ~/memevents-20120511 -model $m src/$bn.litmus | ./memevts-to-status.pl
  done
  echo "ok" 1>&2
done

