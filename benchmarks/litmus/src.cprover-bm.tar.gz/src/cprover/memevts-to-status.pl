#!/usr/bin/perl -w

use strict;

my $expect=undef;

while(<>)
{
  if(/^Test\s+\S+\s+(Allowed|Forbidden|Required)$/)
  {
    if($1 eq "Required")
    {
      $expect="unknown\n";
      last;
    }
    else
    {
      $expect=$1;
    }
  }
  elsif(/^(Ok$|No )/)
  {
    defined($expect) or die "Invalid\n";
    if($expect eq "Allowed")
    {
      $expect=$1 eq "Ok" ? "invalid" : "valid";
    }
    else
    {
      $expect=$1 eq "Ok" ? "valid" : "invalid";
    }
    last;
  }
}

defined($expect) or die "No data\n";
print "$expect\n";

